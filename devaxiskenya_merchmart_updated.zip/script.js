/**
 * script.js
 * DevAxis Website JavaScript
 *
 * This script handles interactive elements and dynamic behaviors of the DevAxis website,
 * including mobile menu functionality, smooth scrolling, scroll-based animations,
 * contact form handling, dynamic year updates, parallax effects, and various interactive effects.
 */

// --- DOM Element Caching ---
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const navLinks = document.querySelector('.nav-links');
const nav = document.querySelector('.nav');
const sections = document.querySelectorAll('section[id]');
const navLinksArray = document.querySelectorAll('.nav-link');
const contactForm = document.getElementById('contactForm');
const body = document.body;

// --- Utility Functions ---

/**
 * Debounces a function, ensuring it's only called after a certain delay
 * since the last time it was invoked.
 * @param {Function} func The function to debounce.
 * @param {number} delay The delay in milliseconds.
 * @returns {Function} The debounced function.
 */
const debounce = (func, delay) => {
    let timeout;
    return function(...args) {
        const context = this;
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(context, args), delay);
    };
};

/**
 * Throttles a function, ensuring it's called at most once within a given period.
 * @param {Function} func The function to throttle.
 * @param {number} limit The time limit in milliseconds.
 * @returns {Function} The throttled function.
 */
const throttle = (func, limit) => {
    let inThrottle;
    return function(...args) {
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => (inThrottle = false), limit);
        }
    };
};

// --- Mobile Menu Functionality ---
mobileMenuBtn?.addEventListener('click', () => {
    navLinks.classList.toggle('active');
    mobileMenuBtn.classList.toggle('active');
    const isExpanded = mobileMenuBtn.classList.contains('active');
    mobileMenuBtn.setAttribute('aria-expanded', isExpanded);
    // Prevent/allow background scrolling
    if (isExpanded) {
        body.style.overflow = 'hidden';
    } else {
        body.style.overflow = '';
    }
});

// --- Smooth Scroll for Navigation Links ---
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
            // Close mobile menu if open
            if (navLinks.classList.contains('active')) {
                navLinks.classList.remove('active');
                mobileMenuBtn.classList.remove('active');
                mobileMenuBtn.setAttribute('aria-expanded', 'false');
                body.style.overflow = ''; // Re-enable scrolling
            }
        }
    });
});

// --- Consolidated Scroll Event Handler ---
let lastScroll = 0;
const handleScroll = () => {
    const currentScroll = window.pageYOffset;

    // Navbar scroll effect
    if (currentScroll <= 0) {
        nav.classList.remove('scroll-up', 'scroll-down');
    } else if (currentScroll > lastScroll && !nav.classList.contains('scroll-down')) {
        nav.classList.remove('scroll-up');
        nav.classList.add('scroll-down');
    } else if (currentScroll < lastScroll && nav.classList.contains('scroll-down')) {
        nav.classList.remove('scroll-down');
        nav.classList.add('scroll-up');
    }
    lastScroll = currentScroll;

    // Parallax effect for hero background
    const heroBackground = document.querySelector('.hero-background');
    if (heroBackground && currentScroll < window.innerHeight) {
        heroBackground.style.transform = `translateY(${currentScroll * 0.5}px)`;
    }

    // Active state for nav links based on scroll position
    let currentSectionId = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        // Adjust offset to trigger active state a bit before the section is fully in view
        if (currentScroll >= sectionTop - nav.offsetHeight - 50) { 
            currentSectionId = section.getAttribute('id');
        }
    });
    
    navLinksArray.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${currentSectionId}`) {
            link.classList.add('active');
        }
    });
};

window.addEventListener('scroll', throttle(handleScroll, 100)); // Throttle scroll events

// --- Intersection Observer for fade-in animations ---
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
            observer.unobserve(entry.target); // Stop observing once animated
        }
    });
}, observerOptions);

// Observe all service cards, project cards, and sections
document.querySelectorAll('.service-card, .project-card, .about-grid, .contact-grid').forEach(el => {
    observer.observe(el);
});

// --- Contact Form Handling ---
const showNotification = (message, isSuccess) => {
    const notification = document.createElement('div');
    notification.classList.add('form-notification', isSuccess ? 'success' : 'error');
    notification.textContent = message;
    body.appendChild(notification);

    // Automatically remove notification after a few seconds
    setTimeout(() => {
        notification.remove();
    }, 3000);
};

contactForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(contactForm);
    // In a real application, you would send this data to a backend or service like Formspree
    // For this example, we'll simulate a successful submission.

    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000)); 
        console.log('Form submitted:', Object.fromEntries(formData));
        showNotification('Thank you for your message! We\'ll get back to you soon.', true);
        contactForm.reset();
    } catch (error) {
        console.error('Form submission error:', error);
        showNotification('Error sending message. Please try again.', false);
    }
});

// --- Dynamic year in footer ---
const yearElement = document.querySelector('.footer-bottom p');
if (yearElement) {
    const currentYear = new Date().getFullYear();
    yearElement.textContent = `© ${currentYear} DevAxis. All rights reserved.`;
}

// --- Add typing effect to hero tag ---
const heroTag = document.querySelector('.hero-tag');
if (heroTag) {
    const text = heroTag.textContent;
    heroTag.textContent = '';
    let i = 0;
    
    const typeWriter = () => {
        if (i < text.length) {
            heroTag.textContent += text.charAt(i);
            i++;
            setTimeout(typeWriter, 100);
        }
    };
    
    // Start typing after page load
    setTimeout(typeWriter, 500);
}

// --- Project card reveal on scroll (using IntersectionObserver) ---
const projectCards = document.querySelectorAll('.project-card');
const projectObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
        if (entry.isIntersecting) {
            setTimeout(() => {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }, index * 100);
            projectObserver.unobserve(entry.target); // Stop observing once animated
        }
    });
}, { threshold: 0.1 });

projectCards.forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(30px)';
    card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    projectObserver.observe(card);
});

// --- Add glitch effect to logo on hover ---
const logo = document.querySelector('.logo');
if (logo) {
    logo.addEventListener('mouseenter', () => {
        logo.classList.add('glitch');
        setTimeout(() => {
            logo.classList.remove('glitch');
        }, 500);
    });
}

// --- Service card tilt effect ---
document.querySelectorAll('.service-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        const rotateX = (y - centerY) / 10;
        const rotateY = (centerX - x) / 10;
        
        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-5px)`;
    });
    
    card.addEventListener('mouseleave', () => {
        card.style.transform = '';
    });
});

// --- Stats counter animation ---
const animateCounter = (element, target, duration = 2000) => {
    let start = 0;
    const increment = target / (duration / 16); // 60 FPS
    
    const updateCounter = () => {
        start += increment;
        if (start < target) {
            element.textContent = Math.floor(start) + '+';
            requestAnimationFrame(updateCounter);
        } else {
            element.textContent = target + '+';
        }
    };
    
    updateCounter();
};

// Observe stats and trigger counter animation
const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting && !entry.target.classList.contains('counted')) {
            entry.target.classList.add('counted');
            const number = entry.target.querySelector('.stat-number');
            const targetValue = parseInt(number.textContent);
            if (!isNaN(targetValue)) {
                animateCounter(number, targetValue);
            }
            statsObserver.unobserve(entry.target); // Stop observing once animated
        }
    });
}, { threshold: 0.5 });

document.querySelectorAll('.stat').forEach(stat => {
    statsObserver.observe(stat);
});

// --- Initial Load Animation ---
window.addEventListener('load', () => {
    body.classList.add('loaded');
});

// Add CSS for notification (to be added to style.css or dynamically injected)
/*
.form-notification {
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    padding: 15px 25px;
    border-radius: 8px;
    color: var(--dark);
    font-weight: 600;
    z-index: 10000;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    opacity: 0;
    animation: fadeInOut 3.5s forwards;
}

.form-notification.success {
    background-color: var(--primary);
}

.form-notification.error {
    background-color: #ff4d4d; // A red color for errors
}

@keyframes fadeInOut {
    0% { opacity: 0; transform: translateX(-50%) translateY(20px); }
    10% { opacity: 1; transform: translateX(-50%) translateY(0); }
    90% { opacity: 1; transform: translateX(-50%) translateY(0); }
    100% { opacity: 0; transform: translateX(-50%) translateY(20px); }
}
*/
